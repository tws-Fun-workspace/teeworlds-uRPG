++++++++++++++++ Teeworlds ++++++++++++++++ 
Copyright (c) 2012 Magnus Auvinen


This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.


Please visit http://www.teeworlds.com for up-to-date information about 
the game, including new versions, custom maps and much more.


++++++++++++++++ OpenFNG ++++++++++++++++
Copyright (c) 2011-2014 Timo Buhrmester

OpenFNG is more or less a free clone of FNG, a modification of teeworlds,
apparently written by some "TOM".
However, OpenFNG does not contain any of the original FNG source, neither
was it used as a template for writing this.
Whoever modifies the OpenFNG code (that is, mainly
src/game/server/gamemodes/openfng.cpp), is required to make his changes
to the source code available to others, when distributing modified
versions of OpenFNG. This shall (not only) avoid the situation out of
which OpenFNG was born in the first place.

Master Repo: http://github.com/fstd/teeworlds
Branch: openfng

IRC: #OpenFNG on Quakenet (irc.quakenet.org)
